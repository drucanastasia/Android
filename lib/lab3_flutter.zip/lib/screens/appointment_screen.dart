import 'package:flutter/material.dart';
import '../main.dart';
import '../models/medical_data.dart';

class AppointmentScreen extends StatelessWidget {
  final AppointmentData data;

  const AppointmentScreen({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 390),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(22, 17, 22, 28),
              children: [
                _header(context),
                const SizedBox(height: 23),
                _doctorInfo(),
                const SizedBox(height: 28),
                Text(
                  data.detailsTitle,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.dark,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  data.description,
                  style: const TextStyle(
                    fontSize: 10,
                    height: 1.35,
                    color: AppColors.grey,
                  ),
                ),
                const SizedBox(height: 42),
                _sectionTitle(data.workingHoursTitle),
                const SizedBox(height: 15),
                _staticOptions(data.hours),
                const SizedBox(height: 24),
                _sectionTitle(data.dateTitle),
                const SizedBox(height: 15),
                _staticOptions(data.dates),
                const SizedBox(height: 72),
                Container(
                  height: 54,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.teal,
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(
                    data.bookLabel,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    return SizedBox(
      height: 42,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              onPressed: () => Navigator.pop(context),
              icon: const Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 21,
                color: AppColors.dark,
              ),
            ),
          ),
          Text(
            data.title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.teal,
            ),
          ),
        ],
      ),
    );
  }

  Widget _doctorInfo() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(7),
          child: Image.network(
            data.avatarUrl,
            width: 96,
            height: 96,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              width: 96,
              height: 96,
              color: AppColors.lightGrey,
              child: const Icon(Icons.person, size: 40),
            ),
          ),
        ),
        const SizedBox(width: 17),
        Expanded(
          child: SizedBox(
            height: 96,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        data.doctorName,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: AppColors.dark,
                        ),
                      ),
                    ),
                    const _ContactIcon(Icons.chat_bubble_outline_rounded),
                    const SizedBox(width: 9),
                    const _ContactIcon(Icons.phone_outlined),
                    const SizedBox(width: 9),
                    const _ContactIcon(Icons.videocam_outlined),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  data.clinic,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF61C6B9),
                  ),
                ),
                const Spacer(),
                Row(
                  children: [
                    const Text(
                      'Payment',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.dark,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      data.payment,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF61C6B9),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 7),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _sectionTitle(String title) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.dark,
            ),
          ),
        ),
        const Text(
          'See All',
          style: TextStyle(fontSize: 11, color: AppColors.dark),
        ),
      ],
    );
  }

  Widget _staticOptions(List<Map<String, dynamic>> slots) {
    return Row(
      children: List.generate(slots.length, (index) {
        final selected = slots[index]['selected'] == true;
        return Expanded(
          child: Container(
            height: 43,
            margin: EdgeInsets.only(right: index < slots.length - 1 ? 10 : 0),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: selected ? AppColors.teal : const Color(0xFFF4F4F4),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              slots[index]['label'] ?? '',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: selected ? Colors.white : AppColors.dark,
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _ContactIcon extends StatelessWidget {
  final IconData icon;
  const _ContactIcon(this.icon);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 23,
      height: 23,
      decoration: const BoxDecoration(
        color: AppColors.iconBg,
        shape: BoxShape.circle,
      ),
      child: Icon(icon, size: 13, color: const Color(0xFF264A4A)),
    );
  }
}
