import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../cubit/medical_cubit.dart';
import '../cubit/medical_state.dart';
import '../main.dart';
import '../models/medical_data.dart';
import '../widgets/doctor_row.dart';
import '../widgets/service_item.dart';
import 'appointment_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<MedicalCubit, MedicalState>(
        builder: (context, state) {
          if (state is MedicalLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (state is MedicalError) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(state.message, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () => context.read<MedicalCubit>().loadData(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          if (state is MedicalEmpty) {
            return _content(
              context,
              state.data,
              const [],
              state.favoriteIds,
              empty: true,
            );
          }

          final success = state as MedicalSuccess;
          return _content(
            context,
            success.data,
            success.visibleDoctors,
            success.favoriteIds,
          );
        },
      ),
    );
  }

  Widget _content(
    BuildContext context,
    MedicalData data,
    List<Doctor> doctors,
    Set<String> favorites, {
    bool empty = false,
  }) {
    final home = data.home;

    return SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 390),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
            children: [
              _topRow(home),
              const SizedBox(height: 22),
              _searchBar(context, home),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AppointmentScreen(
                        data: data.appointment,
                      ),
                    ),
                  );
                },
                child: _appointmentCard(home),
              ),
              const SizedBox(height: 28),
              _sectionTitle('Health Services'),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: home.services
                    .map((service) => ServiceItem(service: service))
                    .toList(),
              ),
              const SizedBox(height: 26),
              _sectionTitle('Nearby Doctor'),
              const SizedBox(height: 16),
              if (empty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 25),
                  child: Center(
                    child: Text(
                      'No doctors found',
                      style: TextStyle(color: AppColors.grey),
                    ),
                  ),
                )
              else
                ...List.generate(doctors.length, (index) {
                  final doctor = doctors[index];
                  return Padding(
                    padding: EdgeInsets.only(
                      bottom: index == doctors.length - 1 ? 0 : 18,
                    ),
                    child: DoctorRow(
                      doctor: doctor,
                      favorite: favorites.contains(doctor.id),
                    ),
                  );
                }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topRow(HomeData home) {
    return Row(
      children: [
        CircleAvatar(
          radius: 20,
          backgroundColor: AppColors.lightGrey,
          backgroundImage:
              home.avatarUrl.isEmpty ? null : NetworkImage(home.avatarUrl),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                home.greeting,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.dark,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                home.subtitle,
                style: const TextStyle(fontSize: 9, color: AppColors.grey),
              ),
            ],
          ),
        ),
        Stack(
          clipBehavior: Clip.none,
          children: [
            const Icon(
              Icons.notifications_none_rounded,
              size: 22,
              color: AppColors.dark,
            ),
            Positioned(
              right: 1,
              top: 1,
              child: Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _searchBar(BuildContext context, HomeData home) {
    return Container(
      height: 48,
      padding: const EdgeInsets.only(left: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFAFC),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.search_rounded,
            color: Color(0xFFB7C0D1),
            size: 22,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              onChanged: context.read<MedicalCubit>().search,
              decoration: InputDecoration(
                hintText: home.searchHint,
                hintStyle: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFFB7C0D1),
                ),
                border: InputBorder.none,
              ),
              style: const TextStyle(fontSize: 11),
            ),
          ),
          IconButton(
            tooltip: 'Sort doctors',
            onPressed: () => context.read<MedicalCubit>().toggleSort(),
            icon: const Icon(
              Icons.tune_rounded,
              color: Color(0xFFB7C0D1),
              size: 21,
            ),
          ),
        ],
      ),
    );
  }

  Widget _appointmentCard(HomeData home) {
    return SizedBox(
      height: 174,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            height: 145,
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            decoration: BoxDecoration(
              color: AppColors.teal,
              borderRadius: BorderRadius.circular(7),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      home.appointmentTitle,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    const Icon(
                      Icons.chevron_right_rounded,
                      color: Colors.white,
                      size: 21,
                    ),
                  ],
                ),
                const SizedBox(height: 17),
                Row(
                  children: [
                    const Icon(
                      Icons.calendar_month_outlined,
                      size: 17,
                      color: Colors.white,
                    ),
                    const SizedBox(width: 9),
                    Text(
                      home.appointmentDate,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(
                      Icons.access_time_rounded,
                      size: 17,
                      color: Colors.white,
                    ),
                    const SizedBox(width: 9),
                    Text(
                      home.appointmentTime,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            right: 17,
            top: 63,
            child: Container(
              width: 38,
              height: 38,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.edit_outlined,
                color: AppColors.teal,
                size: 20,
              ),
            ),
          ),
          Positioned(
            left: 30,
            right: 18,
            bottom: 0,
            child: Container(
              height: 61,
              padding: const EdgeInsets.symmetric(horizontal: 11),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(7),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.04),
                    blurRadius: 12,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 19,
                    backgroundColor: AppColors.lightGrey,
                    backgroundImage: home.appointmentDoctorAvatar.isEmpty
                        ? null
                        : NetworkImage(home.appointmentDoctorAvatar),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          home.appointmentDoctorName,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: AppColors.dark,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          home.appointmentDoctorSpecialty,
                          style: const TextStyle(
                            fontSize: 9,
                            color: AppColors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.chat_bubble_outline_rounded,
                    size: 20,
                    color: Color(0xFF5F6B7A),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppColors.dark,
            ),
          ),
        ),
        const Text(
          'See All',
          style: TextStyle(fontSize: 9, color: AppColors.teal),
        ),
      ],
    );
  }
}
