# Laborator 3

Implementare fără schimbarea structurii vizuale principale a laboratorului anterior.

## Cerințe acoperite
- State management: `flutter_bloc` + `Cubit`
- Stări: `Loading`, `Success`, `Empty`, `Error`
- Încărcare asincronă a datelor din `assets/data/lab_v2.json`
- Modelarea datelor în clase Dart
- Căutare în lista de doctori
- Sortare alfabetică prin iconița de filtru
- Adăugare/eliminare favorite prin inimă
- Navigare Home -> Appointment cu `Navigator.push`
- Revenire cu `Navigator.pop`
- Organizare modulară: `models`, `cubit`, `screens`, `widgets`
- Componente reutilizabile: `DoctorRow`, `ServiceItem`

## Pornire
1. Copiază fișierele în proiect.
2. Rulează `flutter pub get`.
3. Rulează aplicația cu `flutter run`.

Fișierul JSON trebuie să rămână la:
`assets/data/lab_v2.json`
